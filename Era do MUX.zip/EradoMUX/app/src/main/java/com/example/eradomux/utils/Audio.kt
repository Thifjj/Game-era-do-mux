package com.example.eradomux.utils

import android.content.Context
import android.media.MediaPlayer
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.example.eradomux.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object AudioPlayer : DefaultLifecycleObserver {
    private var mediaPlayer: MediaPlayer? = null
    private var isInitialized = false

    // Escopo para rodar coisas em segundo plano
    private val scope = CoroutineScope(Dispatchers.IO)

    fun init(context: Context) {
        if (isInitialized) return

        // MÁGICA AQUI: Rodamos a criação do player em uma thread secundária (IO)
        // Isso impede que o áudio trave quando a tela do jogo está carregando
        scope.launch {
            try {
                val player = MediaPlayer.create(context.applicationContext, R.raw.musica_tema)

                // Configurações do player
                player.apply {
                    isLooping = true
                    setVolume(0.5f, 0.5f)
                    setOnErrorListener { _, _, _ ->
                        // Lógica de recuperação de erro
                        reset()
                        true
                    }
                }

                // Joga de volta para a variável principal
                mediaPlayer = player
                isInitialized = true

                // Inicia suavemente
                startMusic()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onStop(owner: LifecycleOwner) {
        super.onStop(owner)
        try {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.pause()
            }
        } catch (e: Exception) {
            // Ignora erros ao pausar se o player não estiver pronto
        }
    }

    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        startMusic()
    }

    fun startMusic() {
        try {
            if (mediaPlayer != null && !mediaPlayer!!.isPlaying) {
                mediaPlayer?.start()
            }
        } catch (e: Exception) {
            // Proteção contra crash
        }
    }
}