package com.example.eradomux

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.google.firebase.firestore.FirebaseFirestore

// Importamos nossas telas
import com.example.eradomux.ui.TelaLogin
import com.example.eradomux.ui.TelaCadastro
import com.example.eradomux.ui.TelaMenu
import com.example.eradomux.ui.TelaEstatisticas
import com.example.eradomux.ui.TelaConquistas
import com.example.eradomux.ui.TelaJogo
import com.example.eradomux.ui.TelaTutorial
import com.example.eradomux.ui.TelaSelecaoAvatar
import com.example.eradomux.ui.TelaSelecaoFases
import com.example.eradomux.ui.TelaPerfil
import com.example.eradomux.ui.TelaSobre
import com.example.eradomux.ui.TelaTabelaVerdade

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = FirebaseFirestore.getInstance()

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Estado de Navegação
                    var telaAtual by remember { mutableStateOf("login") }

                    // Dados do Usuário Logado
                    var nomeUsuarioLogado by remember { mutableStateOf("") }
                    var tipoUsuarioLogado by remember { mutableStateOf("") }
                    var avatarUsuarioLogado by remember { mutableStateOf(0) } // Avatar real
                    var senhaUsuarioLogado by remember { mutableStateOf("") } // Senha atual

                    // Dados Temporários (Cadastro e Edição de Perfil)
                    var avatarSelecionadoNoCadastro by remember { mutableStateOf(0) }
                    var avatarEdicaoPerfil by remember { mutableStateOf(0) }

                    // Controle do Jogo
                    var faseSelecionada by remember { mutableStateOf(1) }

                    when (telaAtual) {
                        // --- LOGIN ---
                        "login" -> {
                            TelaLogin(
                                onLoginClick = { nome, senha ->
                                    fazerLogin(db, nome, senha) { sucesso, nomeRetornado, tipoRetornado, avatarRetornado ->
                                        if (sucesso) {
                                            nomeUsuarioLogado = nomeRetornado
                                            tipoUsuarioLogado = tipoRetornado
                                            avatarUsuarioLogado = avatarRetornado
                                            senhaUsuarioLogado = senha
                                            telaAtual = "menu"
                                        }
                                    }
                                },
                                onCriarContaClick = { telaAtual = "cadastro" }
                            )
                        }

                        // --- CADASTRO ---
                        "cadastro" -> {
                            TelaCadastro(
                                onVoltarClick = { telaAtual = "login" },
                                onCadastrarClick = { nome, senha, tipo ->
                                    criarConta(db, nome, senha, tipo, avatarSelecionadoNoCadastro) { sucesso ->
                                        if (sucesso) telaAtual = "login"
                                    }
                                },
                                onEscolherAvatarClick = { telaAtual = "selecao_avatar" },
                                currentAvatarId = avatarSelecionadoNoCadastro
                            )
                        }

                        "selecao_avatar" -> {
                            TelaSelecaoAvatar(
                                onVoltarClick = { telaAtual = "cadastro" },
                                onAvatarSelecionado = { novoId ->
                                    avatarSelecionadoNoCadastro = novoId
                                    telaAtual = "cadastro"
                                }
                            )
                        }

                        // --- MENU PRINCIPAL ---
                        "menu" -> {
                            TelaMenu(
                                nomeJogador = nomeUsuarioLogado,
                                tipoJogador = tipoUsuarioLogado,
                                avatarId = avatarUsuarioLogado,
                                onNavegar = { destino ->
                                    when (destino) {
                                        "Jogar" -> telaAtual = "selecao_fases"
                                        "Tutorial" -> telaAtual = "tutorial"
                                        "Estatísticas" -> telaAtual = "estatisticas"
                                        "Perfil" -> {
                                            avatarEdicaoPerfil = avatarUsuarioLogado // Sincroniza edição
                                            telaAtual = "perfil"
                                        }
                                        "Sobre" -> telaAtual = "sobre"
                                    }
                                },
                                onSairClick = {
                                    // Limpa dados ao sair
                                    nomeUsuarioLogado = ""
                                    tipoUsuarioLogado = ""
                                    avatarUsuarioLogado = 0
                                    telaAtual = "login"
                                }
                            )
                        }

                        "selecao_fases" -> {
                            TelaSelecaoFases(
                                nomeJogador = nomeUsuarioLogado,
                                onVoltarClick = { telaAtual = "menu" },
                                onFaseClick = { numeroFase ->
                                    // SE FOR A FASE 4 (ESPECIAL), VAI PARA A TABELA VERDADE
                                    if (numeroFase == 4) {
                                        faseSelecionada = numeroFase
                                        telaAtual = "tabela_verdade"
                                    } else {
                                        // SENÃO, VAI PARA O JOGO DE GRID
                                        faseSelecionada = numeroFase
                                        Toast.makeText(this, "Carregando Fase $numeroFase...", Toast.LENGTH_SHORT).show()
                                        telaAtual = "jogo"
                                    }
                                }
                            )
                        }

                        // --- NOVO CASO: TABELA VERDADE ---
                        "tabela_verdade" -> {
                            TelaTabelaVerdade(
                                nomeJogador = nomeUsuarioLogado,
                                onVoltarClick = { telaAtual = "selecao_fases" },
                                onFaseConcluida = {
                                    // Salva progresso no DB (para desbloquear o próximo nível)
                                    salvarProgressoFase(db, nomeUsuarioLogado, 4) {
                                        telaAtual = "selecao_fases" // Volta para o mapa de seleção
                                    }
                                }
                            )
                        }

                        // --- JOGO (Grid ou MUX) ---
                        "jogo" -> {
                            TelaJogo(
                                nivelAtual = faseSelecionada,
                                avatarId = avatarUsuarioLogado,
                                nomeJogador = nomeUsuarioLogado, // Passa nome para salvar progresso
                                onVoltarMenu = { telaAtual = "selecao_fases" }, // Volta para o mapa, não menu principal
                                onFaseConcluida = {
                                    salvarProgressoFase(db, nomeUsuarioLogado, faseSelecionada) {
                                        telaAtual = "selecao_fases"
                                    }
                                }
                            )
                        }

                        // --- ESTATÍSTICAS E CONQUISTAS ---
                        "estatisticas" -> {
                            TelaEstatisticas(
                                nomeJogador = nomeUsuarioLogado,
                                avatarId = avatarUsuarioLogado,
                                onVoltarClick = { telaAtual = "menu" },
                                onConquistasClick = { telaAtual = "conquistas" }
                            )
                        }

                        "conquistas" -> {
                            TelaConquistas(
                                nomeJogador = nomeUsuarioLogado,
                                avatarId = avatarUsuarioLogado,
                                onVoltarClick = { telaAtual = "estatisticas" }
                            )
                        }

                        // --- TUTORIAL E SOBRE ---
                        "tutorial" -> {
                            TelaTutorial(
                                nomeJogador = nomeUsuarioLogado,
                                avatarId = avatarUsuarioLogado,
                                onVoltarClick = { telaAtual = "menu" }
                            )
                        }

                        "sobre" -> {
                            TelaSobre(
                                onVoltarClick = { telaAtual = "menu" }
                            )
                        }

                        // --- PERFIL E EDIÇÃO ---
                        "perfil" -> {
                            TelaPerfil(
                                nome = nomeUsuarioLogado,
                                tipo = tipoUsuarioLogado,
                                senhaAtual = senhaUsuarioLogado,
                                avatarId = avatarEdicaoPerfil,
                                onVoltarClick = { telaAtual = "menu" },
                                onTrocarAvatarClick = { telaAtual = "selecao_avatar_perfil" },
                                onSalvarClick = { novaSenha ->
                                    atualizarPerfil(db, nomeUsuarioLogado, novaSenha, avatarEdicaoPerfil) {
                                        senhaUsuarioLogado = novaSenha
                                        avatarUsuarioLogado = avatarEdicaoPerfil
                                        telaAtual = "menu"
                                    }
                                }
                            )
                        }

                        "selecao_avatar_perfil" -> {
                            TelaSelecaoAvatar(
                                onVoltarClick = { telaAtual = "perfil" },
                                onAvatarSelecionado = { novoId ->
                                    avatarEdicaoPerfil = novoId
                                    telaAtual = "perfil"
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // --- FUNÇÕES DE BANCO DE DADOS ---

    private fun fazerLogin(
        db: FirebaseFirestore,
        nome: String,
        senha: String,
        onResult: (Boolean, String, String, Int) -> Unit
    ) {
        if (nome.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            return
        }
        db.collection("usuarios")
            .whereEqualTo("nome", nome)
            .whereEqualTo("senha", senha)
            .get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val doc = documents.documents[0]
                    val tipo = doc.getString("classe") ?: "Aluno"
                    val nomeReal = doc.getString("nome") ?: nome
                    val avatarId = doc.getLong("avatarId")?.toInt() ?: 0

                    Toast.makeText(this, "Login realizado!", Toast.LENGTH_SHORT).show()
                    onResult(true, nomeReal, tipo, avatarId)
                } else {
                    Toast.makeText(this, "Dados incorretos.", Toast.LENGTH_SHORT).show()
                    onResult(false, "", "", 0)
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Erro de conexão.", Toast.LENGTH_SHORT).show()
                onResult(false, "", "", 0)
            }
    }

    private fun criarConta(
        db: FirebaseFirestore,
        nome: String,
        senha: String,
        tipo: String,
        avatarId: Int,
        onResult: (Boolean) -> Unit
    ) {
        if (nome.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            onResult(false)
            return
        }

        db.collection("usuarios")
            .whereEqualTo("nome", nome)
            .get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    Toast.makeText(this, "Usuário já existe! Escolha outro nome.", Toast.LENGTH_SHORT).show()
                    onResult(false)
                } else {
                    val novoUsuario = hashMapOf(
                        "nome" to nome,
                        "senha" to senha,
                        "nivel" to 1,
                        "classe" to tipo,
                        "avatarId" to avatarId,
                        "ouro" to 0
                    )

                    db.collection("usuarios")
                        .add(novoUsuario)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Conta criada! Faça login.", Toast.LENGTH_LONG).show()
                            onResult(true)
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "Erro ao criar.", Toast.LENGTH_SHORT).show()
                            onResult(false)
                        }
                }
            }
    }

    private fun salvarProgressoFase(
        db: FirebaseFirestore,
        nomeUsuario: String,
        faseConcluida: Int,
        onSuccess: () -> Unit
    ) {
        db.collection("usuarios")
            .whereEqualTo("nome", nomeUsuario)
            .get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val docId = documents.documents[0].id
                    val nivelAtual = documents.documents[0].getLong("nivel")?.toInt() ?: 1

                    if (faseConcluida >= nivelAtual) {
                        db.collection("usuarios").document(docId)
                            .update("nivel", faseConcluida + 1)
                            .addOnSuccessListener {
                                Toast.makeText(this, "Progresso Salvo!", Toast.LENGTH_SHORT).show()
                                onSuccess()
                            }
                    } else {
                        onSuccess()
                    }
                }
            }
    }

    private fun atualizarPerfil(
        db: FirebaseFirestore,
        nomeUsuario: String,
        novaSenha: String,
        novoAvatarId: Int,
        onSuccess: () -> Unit
    ) {
        db.collection("usuarios")
            .whereEqualTo("nome", nomeUsuario)
            .get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val docId = documents.documents[0].id
                    db.collection("usuarios").document(docId)
                        .update(
                            mapOf(
                                "senha" to novaSenha,
                                "avatarId" to novoAvatarId
                            )
                        )
                        .addOnSuccessListener {
                            Toast.makeText(this, "Perfil atualizado com sucesso!", Toast.LENGTH_SHORT).show()
                            onSuccess()
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "Erro ao atualizar.", Toast.LENGTH_SHORT).show()
                        }
                }
            }
    }
}