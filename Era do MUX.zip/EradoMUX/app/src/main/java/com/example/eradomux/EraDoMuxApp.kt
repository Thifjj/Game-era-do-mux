package com.example.eradomux

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import com.example.eradomux.utils.AudioPlayer

class EraDoMuxApp : Application() {
    override fun onCreate() {
        super.onCreate()

        // 1. Inicializa o Player
        AudioPlayer.init(this)

        // 2. Registra o Player para ouvir o ciclo de vida do APP INTEIRO
        // Isso faz a mágica de pausar no background e voltar no foreground automaticamente
        ProcessLifecycleOwner.get().lifecycle.addObserver(AudioPlayer)
    }
}