package com.example.eradomux.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.* // Importante para os estados
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.eradomux.R
import com.example.eradomux.data.GerenciadorProgresso
import com.google.firebase.firestore.FirebaseFirestore // Import do Firebase

// Modelo simples para representar uma fase
data class Fase(
    val numero: Int,
    val nome: String,
    val estrelasGanhas: Int, // 0 a 3
    val isBloqueada: Boolean = false
)

@Composable
fun TelaSelecaoFases(
    nomeJogador: String,
    onVoltarClick: () -> Unit,
    onFaseClick: (Int) -> Unit
) {
    val context = LocalContext.current

    // Estado para guardar o nível que veio do Banco de Dados
    // Começa com 1 por padrão até carregar do banco
    var nivelMaximoDesbloqueado by remember { mutableStateOf(1) }

    // --- CONSULTA AO FIREBASE ---
    LaunchedEffect(Unit) {
        val db = FirebaseFirestore.getInstance()
        db.collection("usuarios")
            .whereEqualTo("nome", nomeJogador)
            .get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val doc = documents.documents[0]
                    // Pega o nível salvo no banco (Ex: Se completou a fase 1, nível é 2)
                    val nivelBanco = doc.getLong("nivel")?.toInt() ?: 1
                    nivelMaximoDesbloqueado = nivelBanco
                }
            }
    }

    // Cria a lista baseada no nível que veio do FIREBASE
    // Nota: As estrelas ainda vêm do local, mas o bloqueio vem do banco.
    val listaFases = listOf(
        Fase(
            numero = 1,
            nome = "O Início",
            estrelasGanhas = GerenciadorProgresso.getEstrelas(context, nomeJogador, 1),
            isBloqueada = 1 > nivelMaximoDesbloqueado // Se 1 for maior que meu nível, bloqueia
        ),
        Fase(
            numero = 2,
            nome = "Floresta Negra",
            estrelasGanhas = GerenciadorProgresso.getEstrelas(context, nomeJogador, 2),
            isBloqueada = 2 > nivelMaximoDesbloqueado
        ),
        Fase(
            numero = 3,
            nome = "Caverna do Mux",
            estrelasGanhas = GerenciadorProgresso.getEstrelas(context, nomeJogador, 3),
            isBloqueada = 3 > nivelMaximoDesbloqueado
        ),
        Fase(
            numero = 4,
            nome = "Circuito Digital",
            estrelasGanhas = GerenciadorProgresso.getEstrelas(context, nomeJogador, 4),
            isBloqueada = 4 > nivelMaximoDesbloqueado
        )
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // 1. Fundo
        Image(
            painter = painterResource(id = R.drawable.fundomenu), // Ajustado para fundomenu
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // --- 3. LOGO PARCEIRO (Fica atrás da sombra se colocar aqui, se quiser na frente mova para o final) ---
        Box(
            modifier = Modifier.align(Alignment.BottomEnd),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.retangulo_papel),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.width(220.dp).height(80.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.logounivali),
                contentDescription = "Univali",
                modifier = Modifier.height(70.dp).width(220.dp),
                contentScale = ContentScale.Fit
            )
        }

        // Sombra escura
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)))

        // 2. Conteúdo
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // --- CABEÇALHO ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Botão Voltar
                BotaoMedieval(text = "Voltar", onClick = onVoltarClick)

                Spacer(modifier = Modifier.weight(1f))

                // Título
                Text(
                    text = "Mapa do Reino",
                    color = CorDourado,
                    fontSize = 28.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.width(40.dp))
            }

            Spacer(modifier = Modifier.height(24.dp))

            // --- GRID DE FASES ---
            LazyVerticalGrid(
                columns = GridCells.Fixed(2), // 2 Colunas
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(listaFases) { fase ->
                    CardFase(fase = fase, onClick = { onFaseClick(fase.numero) })
                }
            }
        }
    }
}

@Composable
fun CardFase(fase: Fase, onClick: () -> Unit) {
    val corFundo = if (fase.isBloqueada) Color.DarkGray else CorVermelhoBotao.copy(alpha = 0.9f)
    val corBorda = if (fase.isBloqueada) Color.Gray else CorDourado
    val corTexto = if (fase.isBloqueada) Color.Gray else CorDourado

    Box(
        modifier = Modifier
            .height(140.dp)
            .background(corFundo, RoundedCornerShape(12.dp))
            .border(2.dp, corBorda, RoundedCornerShape(12.dp))
            .clickable(enabled = !fase.isBloqueada) { onClick() }
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Fase ${fase.numero}",
                color = corTexto,
                fontFamily = FontFamily.Serif,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = if (fase.isBloqueada) "Bloqueado" else fase.nome,
                color = Color.White.copy(alpha = 0.8f),
                fontFamily = FontFamily.Serif,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Estrelas
            if (!fase.isBloqueada) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(3) { index ->
                        val corEstrela = if (index < fase.estrelasGanhas) CorDourado else Color.Black.copy(alpha = 0.5f)
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = corEstrela,
                            modifier = Modifier.size(32.dp).padding(horizontal = 2.dp)
                        )
                    }
                }
            }
        }
    }
}