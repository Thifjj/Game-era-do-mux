package com.example.eradomux.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.eradomux.R

@Composable
fun TelaLogin(
    onLoginClick: (String, String) -> Unit,
    onCriarContaClick: () -> Unit // <--- CORREÇÃO: Agora não recebe parâmetros (era String, String)
) {
    var nome by remember { mutableStateOf("") }
    var senha by remember { mutableStateOf("") }

    Box(modifier = Modifier.fillMaxSize()) {

        Image(painter = painterResource(id = R.drawable.backgroundlogin), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())

        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.3f)))

        Row(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Image(
                painter = painterResource(id = R.drawable.eradomux),
                contentDescription = "Logo",
                modifier = Modifier.weight(1f).aspectRatio(1f).padding(end = 16.dp).align(Alignment.CenterVertically)
            )

            Box(
                modifier = Modifier.weight(1.2f).background(CorFundoTransparente, shape = RoundedCornerShape(4.dp)).padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {

                    Text(text = "Digite seu nome:", color = CorDourado, fontFamily = FontFamily.Serif, fontSize = 18.sp, modifier = Modifier.align(Alignment.Start).padding(bottom = 4.dp))
                    CampoMedieval(value = nome, onValueChange = { nome = it }, placeholder = "Nome")

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(text = "Digite sua senha :", color = CorDourado, fontFamily = FontFamily.Serif, fontSize = 18.sp, modifier = Modifier.align(Alignment.Start).padding(bottom = 4.dp))
                    CampoMedieval(value = senha, onValueChange = { senha = it }, placeholder = "Senha", isPassword = true)

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        BotaoMedieval(text = "Login", onClick = { onLoginClick(nome, senha) })

                        // <--- CORREÇÃO: Chama a função sem passar nada
                        BotaoMedieval(text = "Criar conta", onClick = onCriarContaClick)
                    }
                }
            }
        }
    }
}