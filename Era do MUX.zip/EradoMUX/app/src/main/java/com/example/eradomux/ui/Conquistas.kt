package com.example.eradomux.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.eradomux.R
import com.google.firebase.firestore.FirebaseFirestore

// Modelo de dados para exibir na lista
data class ConquistaData(
    val descricao: String,
    val progressoAtual: Int,
    val meta: Int,
    val concluida: Boolean
)

@Composable
fun TelaConquistas(
    nomeJogador: String,
    avatarId: Int,
    onVoltarClick: () -> Unit
) {
    // 1. Estados para os dados do banco
    var statsFrutas by remember { mutableStateOf(0) }
    var statsCapivaras by remember { mutableStateOf(0) }
    var nivelAtual by remember { mutableStateOf(1) }

    // 2. Buscar dados no Firebase
    LaunchedEffect(Unit) {
        val db = FirebaseFirestore.getInstance()
        db.collection("usuarios")
            .whereEqualTo("nome", nomeJogador)
            .get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    val doc = documents.documents[0]
                    statsFrutas = doc.getLong("stats_frutas")?.toInt() ?: 0
                    statsCapivaras = doc.getLong("stats_capivaras")?.toInt() ?: 0
                    nivelAtual = doc.getLong("nivel")?.toInt() ?: 1
                }
            }
    }

    // 3. Criar a lista de conquistas baseada nos dados reais
    // Aqui definimos as regras!
    val listaConquistas = listOf(
        ConquistaData(
            descricao = "Caçar 5 Capivaras",
            progressoAtual = statsCapivaras,
            meta = 5,
            concluida = statsCapivaras >= 5
        ),
        ConquistaData(
            descricao = "Coletar 5 Frutas",
            progressoAtual = statsFrutas,
            meta = 5,
            concluida = statsFrutas >= 5
        ),
        ConquistaData(
            descricao = "Chegar na Fase 4",
            progressoAtual = if (nivelAtual >= 4) 1 else 0,
            meta = 1,
            concluida = nivelAtual >= 4
        ),
        ConquistaData(
            descricao = "Super Coletor (20 Frutas)",
            progressoAtual = statsFrutas,
            meta = 20,
            concluida = statsFrutas >= 20
        )
    )

    // Lógica do Avatar
    val listaAvatares = listOf(R.drawable.imgperfil, R.drawable.imgperfil2, R.drawable.imgperfil3, R.drawable.imgperfil4)
    val imagemAvatarExibicao = listaAvatares.getOrElse(avatarId) { R.drawable.player }

    Box(modifier = Modifier.fillMaxSize()) {

        // Fundo
        Image(
            painter = painterResource(id = R.drawable.fundomenu),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.3f)))

        // Logo Rodapé
        Box(
            modifier = Modifier.align(Alignment.BottomEnd),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.retangulo_papel),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.width(220.dp).height(80.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.logounivali),
                contentDescription = "Univali",
                modifier = Modifier.height(70.dp).width(220.dp),
                contentScale = ContentScale.Fit
            )
        }

        // CONTEÚDO
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            // ESQUERDA (PERFIL)
            Column(
                modifier = Modifier.weight(0.3f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(id = imagemAvatarExibicao),
                    contentDescription = "Avatar",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(140.dp)
                        .clip(CircleShape)
                        .border(3.dp, CorDourado, CircleShape)
                        .background(Color.Gray)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .background(CorVermelhoEscuro, RoundedCornerShape(4.dp))
                        .border(1.dp, CorDourado, RoundedCornerShape(4.dp))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(text = nomeJogador, color = CorDourado, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }

            // DIREITA (LISTA DINÂMICA)
            Box(
                modifier = Modifier
                    .weight(0.7f)
                    .fillMaxHeight(0.85f)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .border(1.dp, CorDourado.copy(alpha = 0.5f))
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = "Livro de Conquistas",
                        color = CorDourado,
                        fontSize = 22.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp)
                    )

                    HorizontalDivider(color = CorDourado, thickness = 1.dp)

                    LazyColumn(
                        contentPadding = PaddingValues(top = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(listaConquistas) { item ->
                            ItemConquistaDinamico(item)
                        }
                    }
                }
            }
        }

        // Botão Voltar
        Box(modifier = Modifier.align(Alignment.TopStart).padding(16.dp)) {
            BotaoMedieval(text = "Voltar", onClick = onVoltarClick)
        }
    }
}

@Composable
fun ItemConquistaDinamico(item: ConquistaData) {
    val corTexto = if (item.concluida) CorDourado else Color.Gray
    val icone = if (item.concluida) Icons.Default.CheckCircle else Icons.Default.Lock
    val textoProgresso = if (item.concluida) "COMPLETO" else "${item.progressoAtual}/${item.meta}"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (item.concluida) CorVermelhoBotao.copy(alpha=0.3f) else Color.Transparent, RoundedCornerShape(4.dp))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Ícone e Descrição
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(
                imageVector = icone,
                contentDescription = null,
                tint = if (item.concluida) Color.Green else Color.Gray,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = item.descricao,
                color = corTexto,
                fontFamily = FontFamily.Serif,
                fontSize = 16.sp,
                fontWeight = if (item.concluida) FontWeight.Bold else FontWeight.Normal
            )
        }

        // Progresso (Ex: 3/5)
        Text(
            text = textoProgresso,
            color = if (item.concluida) Color.Green else Color.White,
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
    HorizontalDivider(color = Color.Gray.copy(alpha = 0.2f), thickness = 1.dp)
}