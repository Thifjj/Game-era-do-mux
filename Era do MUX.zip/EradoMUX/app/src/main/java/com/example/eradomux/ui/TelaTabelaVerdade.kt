package com.example.eradomux.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.eradomux.R
import com.example.eradomux.data.GerenciadorProgresso

val CorLinhaPorta = Color.Black
const val EspessuraLinha = 3f

// NOVO DATA MODEL (COM ESTADO OBSERVÁVEL)
data class TruthTableRow(
    val a: Int,
    val b: Int,
    var qUsuarioState: MutableState<Int> // <--- CHAVE PARA O FUNCIONAMENTO
)

@Composable
fun TelaTabelaVerdade(
    nomeJogador: String,
    onVoltarClick: () -> Unit,
    onFaseConcluida: () -> Unit // Chamado ao acertar para salvar progresso
) {
    val nivelAtual = 4
    val context = LocalContext.current

    // Inicialização da Tabela com ESTADOS OBSERVÁVEIS
    val tabela = remember {
        mutableStateListOf(
            TruthTableRow(0, 0, mutableStateOf(0)),
            TruthTableRow(0, 1, mutableStateOf(0)),
            TruthTableRow(1, 0, mutableStateOf(0)),
            TruthTableRow(1, 1, mutableStateOf(0))
        )
    }

    var verificacaoCompleta by remember { mutableStateOf(false) }
    var mensagemErro by remember { mutableStateOf("") }
    // Define uma cor verde forte para o sucesso e vermelho para o teste/erro
    val CorSucessoVerde = Color(0xFF008000)
    val corBotao = if (verificacaoCompleta) CorSucessoVerde else CorVermelhoBotao

    // Lógica de Verificação
    val verificarTabela = {
        var todosCorretos = true
        val portaLogica = { a: Int, b: Int -> if (a == 1 && b == 1) 1 else 0 }

        tabela.forEach { row ->
            val saidaReal = portaLogica(row.a, row.b)
            if (row.qUsuarioState.value != saidaReal) {
                todosCorretos = false
            }
        }

        if (todosCorretos) {
            val estrelasGanhas = 3
            GerenciadorProgresso.salvarEstrelas(context, nomeJogador, nivelAtual, estrelasGanhas)
            verificacaoCompleta = true
            mensagemErro = "" // Limpa a mensagem de erro
        } else {
            verificacaoCompleta = false
            mensagemErro = "A tabela está incorreta! Reveja a lógica da porta AND."
        }
    }


    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF2C2C2C))) {

        // Fundo
        Image(
            painter = painterResource(id = R.drawable.backgroundlogin),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.3f)))


        // CONTEÚDO PRINCIPAL (Centralizado e Rolável)
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.9f)
                .align(Alignment.Center)
                .background(Color.White, RoundedCornerShape(8.dp))
                .border(4.dp, CorDourado, RoundedCornerShape(8.dp))
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // HEADER (Visualmente ajustado e com Box)
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Nível Especial",
                    color = Color.Black,
                    fontFamily = FontFamily.Serif,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // BOX ESTILO ERA DO MUX (Título em Destaque)
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .background(CorVermelhoEscuro, RoundedCornerShape(4.dp))
                        .border(2.dp, CorDourado, RoundedCornerShape(4.dp))
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Acerte a tabela verdade:",
                            color = CorTextoBranco,
                            fontFamily = FontFamily.Serif,
                            fontSize = 18.sp,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "PORTA AND",
                            color = CorDourado,
                            fontFamily = FontFamily.Serif,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            // --- CORPO (GATE + TABLE) ---
            Row(
                modifier = Modifier.fillMaxWidth().height(200.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. SÍMBOLO DA PORTA LÓGICA
                Box(modifier = Modifier.size(150.dp).padding(start = 20.dp), contentAlignment = Alignment.Center) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawAndGateSymbol(this)
                    }
                    // Labels A e B
                    Text("A", color = Color.Black, fontSize = 18.sp, modifier = Modifier.align(Alignment.TopStart).offset(y = (-5).dp))
                    Text("B", color = Color.Black, fontSize = 18.sp, modifier = Modifier.align(Alignment.BottomStart).offset(y = (5).dp))
                    Text("Q", color = Color.Black, fontSize = 18.sp, modifier = Modifier.align(Alignment.CenterEnd).offset(x = (15).dp))
                }

                // 2. TABELA DE VERDADE
                TabelaVerdadeComponent(tabela = tabela, isLocked = verificacaoCompleta)
            }

            Spacer(modifier = Modifier.height(30.dp))

            // FOOTER (BOTÃO + MENSAGEM)
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {

                // MENSAGEM DE SUCESSO OU ERRO
                if (verificacaoCompleta) {
                    Text(
                        text = "Parabéns! Você acertou a Tabela Verdade! 🌟",
                        color = CorSucessoVerde,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }
                else if (mensagemErro.isNotEmpty()) {
                    Text(
                        mensagemErro,
                        color = Color.Red,
                        fontFamily = FontFamily.Serif,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                Button(
                    onClick = {
                        if (verificacaoCompleta) {
                            onFaseConcluida()
                        } else {
                            verificarTabela()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = corBotao),
                    modifier = Modifier.fillMaxWidth(0.5f).height(50.dp)
                ) {
                    Text(
                        text = if (verificacaoCompleta) "CONTINUAR" else "TESTAR",
                        color = CorTextoBranco,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Botão Voltar (Flutuante no Topo Esquerdo)
        Button(
            onClick = onVoltarClick,
            colors = ButtonDefaults.buttonColors(containerColor = Color.Black.copy(alpha = 0.6f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, CorDourado),
            modifier = Modifier.align(Alignment.TopStart).padding(16.dp)
        ) {
            Text("Voltar", color = CorDourado, fontFamily = FontFamily.Serif)
        }
    }
}

// =================================================================================
// COMPONENTES AUXILIARES (Mantidos)
// =================================================================================

@Composable
fun TabelaVerdadeComponent(tabela: List<TruthTableRow>, isLocked: Boolean) {
    Column(modifier = Modifier.width(IntrinsicSize.Max)) {
        // --- CABEÇALHO ---
        Row(modifier = Modifier.fillMaxWidth().background(Color.LightGray)) {
            TabelaCelulaHeader("A")
            TabelaCelulaHeader("B")
            TabelaCelulaHeader("Q=(A.B)") // Título corrigido
        }

        // --- LINHAS DE DADOS ---
        tabela.forEach { row ->
            Row(modifier = Modifier.fillMaxWidth()) {
                TabelaCelula(valor = row.a.toString(), isData = true, onClick = {})
                TabelaCelula(valor = row.b.toString(), isData = true, onClick = {})

                // Coluna Q (Clicável para Input)
                TabelaCelula(
                    valor = row.qUsuarioState.value.toString(), // <--- LÊ O VALOR DO ESTADO
                    isData = false,
                    isClickable = !isLocked,
                    onClick = {
                        // Altera o valor do ESTADO OBSERVÁVEL
                        row.qUsuarioState.value = 1 - row.qUsuarioState.value
                    }
                )
            }
        }
    }
}

@Composable
fun RowScope.TabelaCelulaHeader(label: String) {
    Text(
        text = label,
        modifier = Modifier
            .weight(1f)
            .border(1.dp, Color.Black)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        textAlign = TextAlign.Center,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Serif,
        fontSize = 14.sp
    )
}

@Composable
fun RowScope.TabelaCelula(valor: String, isData: Boolean, isClickable: Boolean = false, onClick: () -> Unit) {
    val backgroundColor = if (isClickable) Color(0xFFEEEEEE) else Color.White

    Box(
        modifier = Modifier
            .weight(1f)
            .border(1.dp, Color.Black)
            .background(backgroundColor)
            .clickable(enabled = isClickable) { onClick() }
            .padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = valor,
            color = if (isData) Color.DarkGray else CorVermelhoEscuro,
            fontWeight = if (isData) FontWeight.Normal else FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            fontSize = 16.sp // Tamanho ligeiramente maior para o valor do bit
        )
    }
}

// --- FUNÇÕES DE DESENHO --- (Mantidas)

fun DrawScope.drawAndGateSymbol(scope: DrawScope) {
    val size = scope.size
    val w = size.width
    val h = size.height
    val borderColor = CorLinhaPorta
    val strokeWidth = 3f

    // Corpo D-shape (AND Gate)
    val path = Path().apply {
        moveTo(w * 0.2f, h * 0.25f)
        lineTo(w * 0.5f, h * 0.25f)
        arcTo(
            rect = Rect(w * 0.5f, h * 0.25f, w * 0.9f, h * 0.75f),
            startAngleDegrees = -90f,
            sweepAngleDegrees = 180f,
            forceMoveTo = false
        )
        lineTo(w * 0.2f, h * 0.75f)
        close()
    }

    scope.drawPath(path, borderColor, style = Stroke(width = strokeWidth))

    // Linha A (Input 1)
    scope.drawLine(color = borderColor, start = Offset(0f, h * 0.35f), end = Offset(w * 0.2f, h * 0.35f), strokeWidth = strokeWidth)
    // Linha B (Input 2)
    scope.drawLine(color = borderColor, start = Offset(0f, h * 0.65f), end = Offset(w * 0.2f, h * 0.65f), strokeWidth = strokeWidth)
    // Saída Q
    scope.drawLine(color = borderColor, start = Offset(w * 0.9f, h * 0.5f), end = Offset(w, h * 0.5f), strokeWidth = strokeWidth)
}