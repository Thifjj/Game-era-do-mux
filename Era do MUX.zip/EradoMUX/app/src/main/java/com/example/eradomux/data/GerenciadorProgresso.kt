package com.example.eradomux.data

import android.content.Context

object GerenciadorProgresso {
    private const val NOME_ARQUIVO = "save_era_do_mux"

    // AGORA RECEBE O USERNAME
    fun salvarEstrelas(context: Context, username: String, nivel: Int, estrelas: Int) {
        val prefs = context.getSharedPreferences(NOME_ARQUIVO, Context.MODE_PRIVATE)

        // A chave agora é única por usuário: "thiago_fase_1_estrelas"
        val chaveEstrelas = "${username}_fase_${nivel}_estrelas"
        val chaveBloqueioProx = "${username}_fase_${nivel + 1}_bloqueada"

        val estrelasAtuais = prefs.getInt(chaveEstrelas, 0)

        if (estrelas > estrelasAtuais) {
            val editor = prefs.edit()
            editor.putInt(chaveEstrelas, estrelas)
            if (estrelas > 0) {
                editor.putBoolean(chaveBloqueioProx, false)
            }
            editor.apply()
        }
    }

    fun getEstrelas(context: Context, username: String, nivel: Int): Int {
        val prefs = context.getSharedPreferences(NOME_ARQUIVO, Context.MODE_PRIVATE)
        return prefs.getInt("${username}_fase_${nivel}_estrelas", 0)
    }

    fun isFaseBloqueada(context: Context, username: String, nivel: Int): Boolean {
        if (nivel == 1) return false
        val prefs = context.getSharedPreferences(NOME_ARQUIVO, Context.MODE_PRIVATE)
        return prefs.getBoolean("${username}_fase_${nivel}_bloqueada", true)
    }
}