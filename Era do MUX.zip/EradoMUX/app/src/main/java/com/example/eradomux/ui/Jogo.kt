package com.example.eradomux.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.example.eradomux.R
import com.example.eradomux.data.GerenciadorProgresso
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

// Tipos de blocos no mapa
enum class TipoBloco { CHAO, ARBUSTO, JAVALI, CASA }
enum class Comando { FRENTE, ESQUERDA, DIREITA, ACAO }

// Função para encontrar a COORDENADA do arbusto próximo (ATUALIZADA)
fun obterArbustoProximo(mapa: List<List<TipoBloco>>, pos: Pair<Int, Int>): Pair<Int, Int>? {
    val (r, c) = pos
    val vizinhos = listOf(Pair(r - 1, c), Pair(r + 1, c), Pair(r, c - 1), Pair(r, c + 1))
    // Retorna a primeira coordenada vizinha que seja um ARBUSTO
    return vizinhos.firstOrNull { (nr, nc) ->
        nr in mapa.indices && nc in mapa[0].indices && mapa[nr][nc] == TipoBloco.ARBUSTO
    }
}

// =================================================================================
// FUNÇÃO PRINCIPAL (ROTEADOR)
// =================================================================================
@Composable
fun TelaJogo(
    nivelAtual: Int,
    avatarId: Int,
    nomeJogador: String,
    onFaseConcluida: () -> Unit,
    onVoltarMenu: () -> Unit
) {
    if (nivelAtual == 4) {
        TelaTabelaVerdade(nomeJogador, onVoltarMenu, onFaseConcluida)
    } else {
        JogoGrid(nivelAtual, avatarId, nomeJogador, onFaseConcluida, onVoltarMenu)
    }
}

// =================================================================================
// FASES 1, 2, 3 (JOGO DE GRID)
// =================================================================================
@Composable
fun JogoGrid(
    nivelAtual: Int,
    avatarId: Int,
    nomeJogador: String,
    onFaseConcluida: () -> Unit,
    onVoltarMenu: () -> Unit
) {
    // --- CONFIGURAÇÃO DAS FASES ---
    val mapaAtual: List<List<TipoBloco>>
    val inicioPlayer: Pair<Int, Int>
    val direcaoInicialPlayer: Int
    val limite3Estrelas: Int
    val limite2Estrelas: Int

    when (nivelAtual) {
        1 -> {
            mapaAtual = listOf(
                listOf(TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.ARBUSTO, TipoBloco.CHAO, TipoBloco.CHAO),
                listOf(TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.ARBUSTO, TipoBloco.CHAO),
                listOf(TipoBloco.CHAO, TipoBloco.ARBUSTO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.JAVALI),
                listOf(TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO),
                listOf(TipoBloco.CASA, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.ARBUSTO, TipoBloco.CHAO)
            ); inicioPlayer = Pair(1, 1); direcaoInicialPlayer = 1; limite3Estrelas = 6; limite2Estrelas = 8
        }
        2 -> {
            mapaAtual = listOf(
                listOf(TipoBloco.CASA, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.ARBUSTO),
                listOf(TipoBloco.ARBUSTO, TipoBloco.ARBUSTO, TipoBloco.ARBUSTO, TipoBloco.ARBUSTO, TipoBloco.ARBUSTO),
                listOf(TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.ARBUSTO, TipoBloco.CHAO, TipoBloco.JAVALI),
                listOf(TipoBloco.CHAO, TipoBloco.ARBUSTO, TipoBloco.ARBUSTO, TipoBloco.ARBUSTO, TipoBloco.CHAO),
                listOf(TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO)
            ); inicioPlayer = Pair(4, 0); direcaoInicialPlayer = 0; limite3Estrelas = 10; limite2Estrelas = 14
        }
        3 -> {
            mapaAtual = listOf(
                listOf(TipoBloco.JAVALI, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.ARBUSTO, TipoBloco.CASA),
                listOf(TipoBloco.ARBUSTO, TipoBloco.ARBUSTO, TipoBloco.CHAO, TipoBloco.ARBUSTO, TipoBloco.CHAO),
                listOf(TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO),
                listOf(TipoBloco.CHAO, TipoBloco.ARBUSTO, TipoBloco.ARBUSTO, TipoBloco.ARBUSTO, TipoBloco.ARBUSTO),
                listOf(TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO, TipoBloco.CHAO)
            ); inicioPlayer = Pair(4, 4); direcaoInicialPlayer = 3; limite3Estrelas = 18; limite2Estrelas = 24
        }
        else -> {
            mapaAtual = listOf(listOf(TipoBloco.CHAO)); inicioPlayer = Pair(0, 0); direcaoInicialPlayer = 0; limite3Estrelas = 5; limite2Estrelas = 10
        }
    }

    // --- ESTADOS DO JOGO ---
    var playerPos by remember(nivelAtual) { mutableStateOf(inicioPlayer) }
    var playerDir by remember(nivelAtual) { mutableStateOf(direcaoInicialPlayer) }
    var comandos by remember(nivelAtual) { mutableStateOf(listOf<Comando>()) }

    var carneColetada by remember(nivelAtual) { mutableStateOf(false) }
    var frutaColetada by remember(nivelAtual) { mutableStateOf(false) }

    // NOVO: Guarda quais árvores foram colhidas (coordena x,y)
    var arbustosColetados by remember(nivelAtual) { mutableStateOf(setOf<Pair<Int, Int>>()) }

    var chegouNaCasa by remember(nivelAtual) { mutableStateOf(false) }

    val animRow = remember(nivelAtual) { Animatable(inicioPlayer.first.toFloat()) }
    val animCol = remember(nivelAtual) { Animatable(inicioPlayer.second.toFloat()) }
    val scope = rememberCoroutineScope()

    var isRunning by remember { mutableStateOf(false) }
    var showPauseMenu by remember { mutableStateOf(false) }
    var showWinDialog by remember { mutableStateOf(false) }
    var mensagemErro by remember { mutableStateOf("") }

    val listaAvatares = listOf(R.drawable.player, R.drawable.player, R.drawable.player, R.drawable.player)
    val imgSpriteSheet = listaAvatares.getOrElse(avatarId) { R.drawable.player }

    // --- LÓGICA DE EXECUÇÃO ---
    LaunchedEffect(isRunning) {
        if (isRunning) {
            mensagemErro = ""
            playerPos = inicioPlayer
            playerDir = direcaoInicialPlayer
            carneColetada = false
            frutaColetada = false
            chegouNaCasa = false
            arbustosColetados = emptySet() // RESET DAS ÁRVORES

            animRow.snapTo(inicioPlayer.first.toFloat())
            animCol.snapTo(inicioPlayer.second.toFloat())
            delay(500)

            for (cmd in comandos) {
                delay(100)
                when (cmd) {
                    Comando.FRENTE -> {
                        val (r, c) = playerPos; var novoR = r; var novoC = c
                        when (playerDir) { 0 -> novoR--; 1 -> novoC++; 2 -> novoR++; 3 -> novoC-- }

                        if (novoR in mapaAtual.indices && novoC in mapaAtual[0].indices) {
                            val blocoAlvo = mapaAtual[novoR][novoC]
                            if (blocoAlvo != TipoBloco.ARBUSTO) {
                                playerPos = Pair(novoR, novoC)
                                launch { animRow.animateTo(novoR.toFloat(), tween(500, easing = LinearEasing)) }
                                launch { animCol.animateTo(novoC.toFloat(), tween(500, easing = LinearEasing)) }
                                delay(500)

                                if (blocoAlvo == TipoBloco.CASA) {
                                    if (carneColetada && frutaColetada) {
                                        chegouNaCasa = true
                                        showWinDialog = true; isRunning = false; return@LaunchedEffect
                                    } else {
                                        mensagemErro = "Faltam itens!"
                                    }
                                }
                            } else {
                                mensagemErro = "Bateu no obstáculo (Pitangueira)!"
                                isRunning = false; return@LaunchedEffect
                            }
                        } else {
                            mensagemErro = "Saiu do mapa!"; isRunning = false; return@LaunchedEffect
                        }
                    }
                    Comando.ESQUERDA -> { playerDir = (playerDir + 3) % 4; delay(300) }
                    Comando.DIREITA -> { playerDir = (playerDir + 1) % 4; delay(300) }

                    // --- ATUALIZAÇÃO DO COMANDO ACAO ---
                    Comando.ACAO -> {
                        if (mapaAtual[playerPos.first][playerPos.second] == TipoBloco.JAVALI) {
                            if (!carneColetada) {
                                carneColetada = true; mensagemErro = "Carne coletada!"
                                incrementarEstatistica(nomeJogador, "stats_capivaras")
                                delay(800)
                            }
                        } else {
                            // Verifica arbusto próximo para coleta individual
                            val arbustoAlvo = obterArbustoProximo(mapaAtual, playerPos)
                            if (arbustoAlvo != null) {
                                if (!arbustosColetados.contains(arbustoAlvo)) {
                                    // Coleta esta árvore específica
                                    arbustosColetados = arbustosColetados + arbustoAlvo
                                    frutaColetada = true // Missão cumprida
                                    mensagemErro = "Fruta coletada!"
                                    incrementarEstatistica(nomeJogador, "stats_frutas")
                                    delay(800)
                                } else {
                                    mensagemErro = "Árvore já vazia."; delay(800)
                                }
                            } else {
                                mensagemErro = "Nada aqui."; delay(800)
                            }
                        }
                    }
                }
            }
            isRunning = false
        }
    }

    // --- UI DA TELA ---
    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF2C2C2C))) {

        Row(modifier = Modifier.fillMaxSize()) {
            // === MAPA (Esquerda) ===
            Box(
                modifier = Modifier
                    .weight(0.7f)
                    .fillMaxHeight()
                    .padding(16.dp)
                    .border(4.dp, CorDourado, RoundedCornerShape(8.dp))
                    .background(Color(0xFF228B22))
            ) {
                // HUD MISSÕES
                Box(modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
                    ListaMissoes(carneColetada, frutaColetada, chegouNaCasa)
                }

                Box(modifier = Modifier.align(Alignment.Center)) {
                    Column {
                        mapaAtual.forEachIndexed { rowIndex, row ->
                            Row {
                                row.forEachIndexed { colIndex, bloco ->
                                    Box(modifier = Modifier.size(60.dp).border(0.5.dp, Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                                        Image(painter = painterResource(id = R.drawable.chao), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())

                                        // RENDERIZAÇÃO DOS OBJETOS
                                        when (bloco) {
                                            TipoBloco.ARBUSTO -> {
                                                // Verifica se ESTE arbusto específico foi colhido
                                                val estaColhido = arbustosColetados.contains(Pair(rowIndex, colIndex))
                                                if (estaColhido) {
                                                    Image(painter = painterResource(id = R.drawable.pitangueirasemfruto), contentDescription = "Vazia", modifier = Modifier.padding(4.dp))
                                                } else {
                                                    Image(painter = painterResource(id = R.drawable.pitangueirasemfundo), contentDescription = "Cheia", modifier = Modifier.padding(4.dp))
                                                }
                                            }
                                            TipoBloco.JAVALI -> {
                                                if (!carneColetada) {
                                                    Image(painter = painterResource(id = R.drawable.capivara), contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(40.dp))
                                                }
                                            }
                                            TipoBloco.CASA -> Image(painter = painterResource(id = R.drawable.casa), contentDescription = null)
                                            else -> {}
                                        }
                                    }
                                }
                            }
                        }
                    }
                    SpriteRenderer(spriteSheetId = imgSpriteSheet, direction = playerDir, modifier = Modifier.size(60.dp).offset(x = (animCol.value * 60).dp, y = (animRow.value * 60).dp).padding(bottom = 8.dp))
                }

                // Mensagem
                if (mensagemErro.isNotEmpty()) {
                    val corFundoStatus = if (carneColetada && frutaColetada) Color(0xFF006400) else Color.Red
                    Box(modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).background(corFundoStatus.copy(alpha = 0.8f), RoundedCornerShape(8.dp)).padding(16.dp)) { Text(mensagemErro, color = Color.White, fontWeight = FontWeight.Bold) }
                }

                // Pause
                Box(modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)) {
                    Button(onClick = { showPauseMenu = true }, colors = ButtonDefaults.buttonColors(containerColor = CorVermelhoBotao)) { Icon(Icons.Default.Menu, contentDescription = "Pause", tint = CorDourado) }
                }
            }

            // === CONTROLES (Direita - Igual) ===
            Column(modifier = Modifier.weight(0.3f).fillMaxHeight().background(Color(0xFF1A1A1A)).padding(8.dp).verticalScroll(rememberScrollState())) {
                Text("Comandos", color = CorDourado, fontSize = 20.sp, fontFamily = FontFamily.Serif)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) { BotaoComando(Icons.Default.KeyboardArrowUp, "Andar") { comandos = comandos + Comando.FRENTE }; BotaoComando(Icons.Default.ThumbUp, "Ação") { comandos = comandos + Comando.ACAO } }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) { BotaoComando(Icons.Default.RotateLeft, "Esq") { comandos = comandos + Comando.ESQUERDA }; BotaoComando(Icons.Default.RotateRight, "Dir") { comandos = comandos + Comando.DIREITA } }
                Spacer(modifier = Modifier.height(16.dp))
                Text("Sua Lógica:", color = Color.Gray, fontSize = 14.sp)
                Box(modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black, RoundedCornerShape(4.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
                    @OptIn(ExperimentalLayoutApi::class)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        comandos.forEachIndexed { index, cmd ->
                            Box(modifier = Modifier.background(Color.DarkGray, RoundedCornerShape(4.dp)).clickable { val n = comandos.toMutableList(); n.removeAt(index); comandos = n }.padding(4.dp)) {
                                Icon(imageVector = when (cmd) { Comando.FRENTE -> Icons.Default.KeyboardArrowUp; Comando.ESQUERDA -> Icons.Default.RotateLeft; Comando.DIREITA -> Icons.Default.RotateRight; Comando.ACAO -> Icons.Default.ThumbUp }, contentDescription = null, tint = Color.Red, modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Button(onClick = { comandos = emptyList(); scope.launch { playerPos = inicioPlayer; playerDir = direcaoInicialPlayer; carneColetada = false; frutaColetada = false; arbustosColetados = emptySet(); animRow.snapTo(inicioPlayer.first.toFloat()); animCol.snapTo(inicioPlayer.second.toFloat()) }; mensagemErro = "" }, colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)) { Icon(Icons.Default.Refresh, null) }
                    Button(onClick = { isRunning = true }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006400)), enabled = !isRunning && comandos.isNotEmpty()) { Icon(Icons.Default.PlayArrow, null); Text("RODAR") }
                }
            }
        }

        // Dialogs (Vitória / Pause)
        if (showWinDialog) {
            val qtdComandos = comandos.size
            val estrelas = when { qtdComandos <= limite3Estrelas -> 3; qtdComandos <= limite2Estrelas -> 2; else -> 1 }
            val context = LocalContext.current
            LaunchedEffect(Unit) { GerenciadorProgresso.salvarEstrelas(context, nomeJogador, nivelAtual, estrelas) }
            AlertDialog(
                onDismissRequest = {}, containerColor = CorDourado,
                title = { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("VITÓRIA!", color = CorVermelhoEscuro, fontWeight = FontWeight.Bold); Row { repeat(3) { i -> Icon(Icons.Default.Star, null, tint = if (i < estrelas) CorVermelhoEscuro else Color.Gray.copy(alpha = 0.4f)) } } } },
                text = { Text("Fase Concluída! Comandos: $qtdComandos", color = Color.Black) },
                confirmButton = { Button(onClick = onFaseConcluida, colors = ButtonDefaults.buttonColors(containerColor = CorVermelhoBotao)) { Text("Continuar") } }
            )
        }
        if (showPauseMenu) {
            AlertDialog(onDismissRequest = { showPauseMenu = false }, containerColor = CorVermelhoEscuro, title = { Text("Pausado", color = CorDourado) },
                text = { Column { Button(onClick = { showPauseMenu = false }, colors = ButtonDefaults.buttonColors(containerColor = CorVermelhoBotao), modifier = Modifier.fillMaxWidth()) { Text("Continuar") }; Spacer(modifier = Modifier.height(8.dp)); Button(onClick = { comandos = emptyList(); scope.launch { playerPos = inicioPlayer; playerDir = direcaoInicialPlayer; animRow.snapTo(inicioPlayer.first.toFloat()); animCol.snapTo(inicioPlayer.second.toFloat()) }; showPauseMenu = false }, colors = ButtonDefaults.buttonColors(containerColor = CorVermelhoBotao), modifier = Modifier.fillMaxWidth()) { Text("Reiniciar") }; Spacer(modifier = Modifier.height(8.dp)); Button(onClick = onVoltarMenu, colors = ButtonDefaults.buttonColors(containerColor = Color.Black), modifier = Modifier.fillMaxWidth()) { Text("Sair") } } }, confirmButton = {}
            )
        }
    }
}

// --- NOVO COMPONENTE: HUD DE MISSÕES ---

@Composable
fun BotaoComando(icon: ImageVector, label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = CorVermelhoBotao),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.size(width = 70.dp, height = 60.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = CorDourado)
            Text(label, fontSize = 10.sp, color = CorDourado)
        }
    }
}

@Composable
fun SpriteRenderer(spriteSheetId: Int, direction: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val imageBitmap = remember(spriteSheetId) {
        ContextCompat.getDrawable(context, spriteSheetId)?.toBitmap()?.asImageBitmap()
    }

    if (imageBitmap != null) {
        Canvas(modifier = modifier) {
            val colunas = 6
            val linhas = 10
            val spriteW = imageBitmap.width / colunas
            val spriteH = imageBitmap.height / linhas

            var flipHorizontal = false
            val linhaParaDesenhar = when (direction) {
                0 -> 5
                1 -> 1
                2 -> 0
                3 -> { flipHorizontal = true; 1 }
                else -> 0
            }
            val colunaParaDesenhar = 0
            val srcX = colunaParaDesenhar * spriteW
            val srcY = linhaParaDesenhar * spriteH

            withTransform({
                if (flipHorizontal) {
                    scale(scaleX = -1f, scaleY = 1f, pivot = center)
                }
            }) {
                drawImage(
                    image = imageBitmap,
                    srcOffset = IntOffset(srcX, srcY),
                    srcSize = IntSize(spriteW, spriteH),
                    dstSize = IntSize(size.width.toInt(), size.height.toInt())
                )
            }
        }
    }
}
@Composable
fun ListaMissoes(
    carneColetada: Boolean,
    frutaColetada: Boolean,
    chegouNaCasa: Boolean
) {
    // Usa BoxWithConstraints se precisasse medir, mas aqui vamos usar weight e fillMaxWidth
    // para garantir que ela ocupe o espaço disponível sem estourar.
    Column(
        modifier = Modifier
            .widthIn(max = 200.dp) // Limita a largura máxima para não cobrir o jogo
            .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
            .border(1.dp, CorDourado, RoundedCornerShape(8.dp))
            .padding(6.dp) // Padding interno menor
    ) {
        Text(
            "Missões:",
            color = CorDourado,
            fontSize = 10.sp, // Fonte menor
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 2.dp)
        )

        ItemMissao("1 Carne", carneColetada)
        ItemMissao("1 Fruta", frutaColetada)
        ItemMissao("Ir p/ Casa", chegouNaCasa)
    }
}

@Composable
fun ItemMissao(texto: String, completo: Boolean) {
    val corTexto = if (completo) Color.Gray else Color.White
    // Estilo riscado se completo
    val textStyle = if (completo) {
        androidx.compose.ui.text.TextStyle(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
    } else {
        androidx.compose.ui.text.TextStyle()
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = if (completo) Icons.Default.Check else Icons.Default.CheckBoxOutlineBlank,
            contentDescription = null,
            tint = if (completo) Color.Green else Color.White,
            modifier = Modifier.size(10.dp) // Ícone menor
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = texto,
            color = corTexto,
            fontSize = 10.sp, // Fonte menor para caber melhor
            style = textStyle,
            maxLines = 1 // Garante que não quebre linha e ocupe muito espaço vertical
        )
    }
}

// Função genérica para somar +1 em qualquer estatística
fun incrementarEstatistica(nomeJogador: String, campoDoBanco: String) {
    val db = FirebaseFirestore.getInstance()

    db.collection("usuarios")
        .whereEqualTo("nome", nomeJogador)
        .get()
        .addOnSuccessListener { documents ->
            if (!documents.isEmpty) {
                val docId = documents.documents[0].id

                // Atualiza o campo somando 1 ao valor atual
                db.collection("usuarios").document(docId)
                    .update(campoDoBanco, FieldValue.increment(1))
            }
        }
}
