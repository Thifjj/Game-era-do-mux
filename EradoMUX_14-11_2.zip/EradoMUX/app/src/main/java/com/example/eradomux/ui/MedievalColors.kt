package com.example.eradomux.ui

import androidx.compose.ui.graphics.Color

// Cores do Tema Medieval
val CorVermelhoEscuro = Color(0xFF4A0E0E)
val CorVermelhoBotao = Color(0xFF6D1515)
val CorDourado = Color(0xFFFFD700)
val CorFundoTransparente = Color(0x99000000) // Preto meio transparente
val CorTextoBranco = Color(0xFFE0E0E0)